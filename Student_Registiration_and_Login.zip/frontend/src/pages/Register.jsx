import { useState } from 'react';
import axios from 'axios';
function Register() {
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [msg, setMsg] = useState('');
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:4000/api/auth/register', form);
      setMsg('Registration successful!');
    } catch (err) {
      setMsg(err.response.data.error);
    }
  };
  return (
    <div className='flex flex-col items-center mt-20'>
      <h2 className='text-2xl font-bold mb-4'>Register</h2>
      <form onSubmit={handleSubmit} className='flex flex-col gap-3 w-72'>
        <input className='border p-2 rounded' placeholder='Name' onChange={(e)=>setForm({...form,name:e.target.value})}/>
        <input className='border p-2 rounded' placeholder='Email' onChange={(e)=>setForm({...form,email:e.target.value})}/>
        <input className='border p-2 rounded' placeholder='Password' type='password' onChange={(e)=>setForm({...form,password:e.target.value})}/>
        <button className='bg-blue-500 text-white p-2 rounded hover:bg-blue-600'>Register</button>
      </form>
      <p className='mt-3 text-green-600'>{msg}</p>
    </div>
  );
}
export default Register;