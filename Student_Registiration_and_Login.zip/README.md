# Project Collaboration Hub (Auth Module)

This is a minimal working prototype for **Student Registration & Login** using:
- Node.js (Express)
- PostgreSQL
- React (Vite)
- Docker Compose

## Quick Start
```bash
docker compose up --build
```
Then open [http://localhost:5173](http://localhost:5173).